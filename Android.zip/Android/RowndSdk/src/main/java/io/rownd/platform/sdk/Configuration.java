/*
 * RowndSdk
 *
 * This file was automatically generated for rownd-sdk by APIMATIC v2.0 ( https://apimatic.io ).
 */
package io.rownd.platform.sdk;


public class Configuration {
    //The base Uri for API calls
    public static String baseUri = "https://api.rownd.io";

    //API Key: Create keys at https://app.rownd.io
    //TODO: Replace the xRowndAppKey with an appropriate value
    public static String xRowndAppKey = "\"TODO: Replace\"";

    //API Secret: Create keys at https://app.rownd.io
    //TODO: Replace the xRowndAppSecret with an appropriate value
    public static String xRowndAppSecret = "\"TODO: Replace\"";

}
